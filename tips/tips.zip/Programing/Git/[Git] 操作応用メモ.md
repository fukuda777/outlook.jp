[Git] 操作応用メモ
==================

## git(git svn) フロー

　　サーバから複製　　: git clone <url>
　　差分を取得　　　　: git fetch --prune
[LOCAL] <--------------------------------------- [SERVER]

[LOCAL]
　　新規ブランチを作成: git branch   <branch名>
　　ブランチを切替　　: git checkout <branch名>
  
　　(ソース修正)
  
　　コミット対象指定　: git add <ファイルパス名>
　　ローカルコミット　: git commit
　　変更状態表示　　　: git status

[LOCAL] ---------------------------------------> [SERVER]
　　サーバへ追加　　　: git push origin <branch名>


```
@startuml
LOCAL <- SERVER : git clone <url>,\n git fetch --prune

activate LOCAL
LOCAL -> LOCAL : 
  新規ブランチを作成: git branch <branch名>,\n
  ブランチを切替: git checkout <branch名>,\n
  (ソース修正) \n
  修正対象指定: git add <ファイルパス>
  コミット: git commit -m "メッセージ"

LOCAL -> SERVER : git push origin <branchname>
@enduml
```


## 用語

・HEAD とは
　現在使用しているブランチの先頭（最新の版コミット）を表す名前です。
　（HEAD の１つ前のブランチは HEAD^ で表せる）

・origin とは
　リモートリポジトリのアクセス先(URL)に対してGitがデフォルトで付ける名前です。

　　originの現在の値(URL)は以下のコマンドで確認可能
　　$ git remote get-url origin

・master ブランチ
　git init コマンドがデフォルトで作るブランチ名が "master" である。
　最初から存在するという以外は、特別なブランチという訳ではありません。

　「origin/master」ブランチ…ローカルにある リモートのmasterブランチを追跡するリモート追跡ブランチ。

・develop ブランチ
　先のリリースに向けた普段の開発で使用するブランチです。先に説明した統合ブランチの役割を担います。

・stash とは、ファイルの変更内容を一時的に記録しておく領域です。
　stashを使うことで、ワークツリーとインデックス中でまだコミットされていない変更を一時的に退避させることができます。
　退避させた変更は後から取り出して、元のブランチや別のブランチに反映させることができます。

・merge とは
　fast-forward(早送り)マージ：
　　masterブランチは単純に移動するだけでbugfixブランチの内容を取り込むことができるマージ
　non fast-forwardマージ：
　　masterブランチでの変更内容とbugfixブランチでの変更内容を一つにまとめるマージ

・rebase： 主軸（ベース）のブランチを別のブランチに付け替えること。
　　bugfixブランチの履歴がmasterブランチの後ろに付け替えられ履歴は一本化されます。
　　rebaseしただけだとmasterの先頭の位置はそのままです。
　　そのため、masterブランチからbugfixブランチをマージして、bugfixの先頭まで移動します。



## develop ブランチを任意のコミットに移動する
　git checkout develop
　git reset <移動先のコミットID, もしくは'名前'>
　＜プッシュ＞


## git ローカルの変更を元に戻す (取り消す)

　全ての変更を取り消す場合は
　git checkout .

　上記で上手くいかない時は"強制"
　git checkout -f .

　特定のファイルorフォルダの変更を取り消したい場合は
　git checkout -- <ファイルorフォルダ名>

　　ちなみに「--」を付けているのは、ブランチ名とファイル名が被った時に、
　　どちらを指しているのかGitが分からなくなるのを避けるためです。


## working tree(ローカルリポジトリ)に別ブランチからファイル/フォルダをコピーする
　git checkout <ブランチ名> — <ファイルorフォルダ名> : 別ブランチからコピーする



## 追跡されていないファイルをすべて削除する
　git clean -f -d
　作業ディレクトリの追跡されていないファイルをすべて削除し、サブディレクトリを空にしてくれます。


## TortoiseGitでのマージ操作

   作業フォルダの右クリックメニューで、「TortoiseGit」＞「マージ」を選択する。
   マージダイアログが開くので、現在のHEADにどの版（コミット）をマージするのか「From」に入力します。
    ⇒ 競合がなくマージを完了すると、「Gitコマンド実行中」画面に「成功」が表示されます。
        「閉じる」ボタンを押して終了。

     「オプション」で「ファーストフォワードしない」を選択せずマージを実行すると、
      ファーストフォワードが可能な場合は、ファーストフォワードします。

    ⇒ 競合があると、Gitコマンド実行中画面が表示され、マージが中断されます。
     1.「競合の解決ボタン」を押すと、コミット画面が表示されます。
     2. コミット画面で競合があるファイルのファイル名をクリックすると、
        TortoiseGitMerge画面が表示されます。左ブロックに「あちら側」として
        マージ画面でFromに指定した版（コミット）の内容が表示され、
        右ブロックに「こちら側」として現在のブランチのHEADの内容が表示されます。
        下ブロックの「マージ済み」で競合の解消を行います。
     3. 「?????・・・」が表示されている部分を修正します。
        行内をクリックすると行を選択することができ、選択した行は太枠で囲まれます。
        コピーや貼り付けをしたり直接入力をして競合を解消します。
     4. 画面上にあるメニューの「解決済みとする」をクリックします。
     5. コミット画面でコミットします。
        コミットを完了すると、「Gitコマンド実行中」画面に「成功」が表示されます。
     6. 「閉じる」ボタンを押します。



## rebase操作
    $ git commit <ブランチ名>
    $ git rebase <リベース先>
    $ git rebase --continue 競合があった場合、ソース変更、add後に継続を実行

  TortoiseGitでのリベース操作
    1. 作業フォルダの右クリックメニューで、「TortoiseGit」＞「リベース（ブランチの付け替え）」を選択する。
    2. リベース画面で、「ブランチ」に新しい主軸のブランチ、「上流」に前の主軸のブランチを入力します。
    3. リベースにより反映される変更が一覧表示されます。採用する変更を確認の上、「リベース開始」をクリックします。
    4. 競合があるとリベースが中断されます。
       リベース画面で競合があったファイルのファイル名をクリックすると、TortoiseGitMerge画面に競合内容が表示されます。
       競合を解消してコミットします。リベースが完了するまで競合の解消を繰り返します。
    5. リベースが完了したら、「終了」をクリックします。


### rebase -i   複数のコミットをまとめる
  -i (--interactive) オプション
    コミットの書き換え、入れ替え、削除、統合を行うことができます。

手順
```
・まとめたいブランチへ移動
$ git checkout <ブランチ名>
・まとめるブランチの数を確認
git log

・リベースを実行
git rebase -i HEAD~<まとめるブランチの数>

commit branchの編集画面が開くので、 2行目以降の "pick" の文字を
    - 1箇所にまとめる場合、"s" (又は "squash") に修正する
    - 削除する場合は、"d" (又は "drop") に修正する
   （pick が指定されているコミットは何もされません）
  → [Ctrl]+[s] [Ctrl]+[x]キー で保存して終了

squashを設定した場合は、commitメッセージ編集画面が再び開くので
  各branchのコメントを編集して1つにまとめる
  → [Ctrl]+[s] [Ctrl]+[x]キー で保存して終了

・結果確認
$ git log

・リモートへ反映 (強制PUSH)
$ git push -f origin  <ブランチ名>
  or
$ git push --force-with-lease origin  <ブランチ名>
```

pushオプション
  --force
    強制PUSH
  --force-with-lease
    強制PUSHだが、リモートと比較してローカルが最新でなければPUSHを行わない

参考
git rebase についてまとめてみた #Git
https://qiita.com/KTakata/items/d33185fc0457c08654a5
git push -f をやめて --force-with-lease を使おう #Git - Qiita
https://qiita.com/wMETAw/items/5f47dcc7cf57af8e449f


  ----------------------------------------
## remote add       他のリポジトリを追加する
git remote add HOGE_HOGE https://hoge.com/hoge/hoge.git

push/pull/rebaseする度にいちいちユーザ名を聞かれるのがめんどくさいという方は、
リポジトリURLにユーザ名やパスワードを含めることもできます。
git remote add HOGE_HOGE https://<USER_NAME>@hoge.com/hoge/hoge.git
git remote add HOGE_HOGE https://<USER_NAME>:<PASSWORD>@hoge.com/hoge/hoge.git

リポジトリアドレスを追加した分も合わせて表示されます。
$ git remote -v
 
HOGE_HOGEをブランチとしてfetchすることができます。
$ git fetch HOGE_HOGE
 
developブランチはorigin/developですが、HOGE_HOGEのdevelopブランチは
HOGE_HOGE/developとしてアクセスすることができます
git branch -r | grep HOGE_HOGE/develop

　追加されたリポジトリのコミットIDでcherry-pickする事も出来るようになります。


## remote set-url   ソース元を変更する
ソース元が別のサーバに引っ越しした時
git remote set-url origin https://hoge2.com/hoge/hoge.git


## cherry-pick      違うブランチのコミットをマージ
    コミットIDに指定した別のブランチを現在のブランチにコピーします。
    $ git checkout <ブランチ名>
    or
    $ git branch <ブランチ名>
    $ git switch <ブランチ名>

    $ git cherry-pick ＜コミットID(修正前)＞..＜コミットID＞
    or
    $ git cherry-pick -m1 ＜コミットID＞
        # -m<数値>  取り込むcommit数を指定する<数値>値は以下の様にして事前に確認
    $ git checkout ＜コミットID＞
    $ git log --graph --decorate
    $ git rev-parse --short=9 HEAD~1 #←修正前のIDが表示される^<数値>

   （コミットIDは 最低7桁以上）

    #fatal: cherry-pick failedが出た場合
    $ meld . &
    #手作業でmergeの修正をする
    $ git add 修正ファイル
    $ git cherry-pick --continue
    $ git status
    #continue失敗時
    $ git commit

    #一応確認
    $ git log --name-status
    $ git show

    #リモートへUPする
    $ git push origin <ブランチ名>

    #cherry-pick終了
    $ git cherry-pick --quit


    source treeでは右クリックよりチェリーピックを選択することで指定のコミットを取り込むことができます。
    （参考）
    sourcetreeでチェリーピックを使ってみる
    http://cly7796.net/wp/other/try-the-cherry-pick-in-sourcetree/



## revert  指定したコミットの内容を打ち消すコミットを追加する（※ツリーに履歴は残る）

　$ git revert HEAD
    先頭のコミット、つまり、直近に行った最後のコミットを取り消すことができます。

	コマンドを実行するとエディタが開くので、コミットメッセージを入力します。
	「Revert "元のコミットメッセージ"」というメッセージが自動で用意されているため、そのままでよい場合は何もせず、保存して終了します。
	「--no-edit」オプションを付けて実行することでエディタを開かずに、自動生成されたメッセージを付けてコミットできます。

	「git revert」を実行しようとした時点で、ワークツリーが変更されていた場合、そのままでは実行できません。



## reset  ローカルのコミットやaddを取り消す
	オプション
	--soft	コミットのみ取り消し
	      	（ワークツリーとインデックスの状態は保持する）
	--mixed	コミットとaddの取り消し
			作業ディレクトリのファイルは消えません。
	--hard	全部を取り消し
			インデックスやワークツリーの変更も破棄して、
			指定したコミットの状態まで戻す。

・インデックスから登録（git add）したファイル変更を取り消す
　$ git reset HEAD
    ファイル名指定なしで、全てのファイルのaddを取り消す。

　$ git reset HEAD [<ファイル名>]
    指定したファイルのaddを取り消す。

・直前のコミットのみを取り消す
　git reset --soft HEAD^
　　HEADだけを書き換える。作業ツリーとインデックスはそのまま。
　　直前のgit commit 実行を取り消す。（まだコミットされていない状態に戻れます。）

・直前のコミットをなかったことにする
　$ git reset --hard HEAD^
　　現時点のインデックスやワークツリーの直前のコミットを取り消す。
　　すべての変更をHEADに合わせる。（※変更は消去されます。）

 ・TortoiseGitにて、マージを取り消す（ローカルのコミットを破棄）
   https://moewe-net.com/version-control/git-merge-reset
　$ git reset --hard ORIG_HEAD
  と同じ事をTortoiseGitでする方法
  マージ先がmasterリポジトリだった場合。 
  　ログ一覧からマージ実行前のログを選んで、右クリック
  　「“master”をここへリセット」を選択し、リセットの種類>Hardにして[OK]ボタン

  <https://scm.dndev.net/sn03/svn/Production_Disp/001_%e3%83%97%e3%83%ad%e3%82%b8%e3%82%a7%e3%82%af%e3%83%88%e7%ae%a1%e7%90%86/20FHI/04_Evidence/GB8/SBR20SC-1180/>

注意点
・git resetはローカルな変更を取り消して元に戻したいときに限って、使用するようにしましょう。

　git resetは「commit を取り消した」というコミット履歴が残りません。
　そのため、リモートリポジトリで公開されているコミットに対して行うと、不整合が発生してしまいます。
　コミットそのものを削除してしまうので、既に他の誰かがコミットを重ねているときにresetしてしまうと、
　存在するはずの親コミットがなくなってしまいます。
　そのため、他のメンバーがpushできなくなります。

・git push 後は「逆向きのコミット」の履歴が残る git revert を使用するようにしましょう。

・間違えてgit reset --hardして必要なコミットを消してしまった場合は、
　「git reflog」を実行してresetを取り消しましょう。


## 直前のコミット(push前)のメッセージ(コメント内容)を修正したい
    (現在のブランチの先頭のコミットに上書き)
　$ git commit --amend



## Gitでプッシュ済みのコミットメッセージを変更する
    https://zenn.dev/suginoki45/articles/c94b05d1155cda

まずはgit logコマンドで該当のコミット履歴を確認。
　$ git log

コミットメッセージを変更したいコミットを指定
例えば該当のコミットが2つ前のものだった場合は以下のようになります。
　$ git rebase -i HEAD~2

変更したいコミットのpickをeditに変更
git rebaseコマンドを実行するとテキストエディタで以下のような表示が出ます。

　例：
　pick c7bg342 サンプルコミット
　pick 16g7f14 メッセージ変更前

修正したいコミットの冒頭のpickをeditに変更して、保存し終了します。

以下のコマンドを実行します。
　$ git commit --amend
コミットメッセージを修正して、保存し終了します。

最後にリモートリポジトリにプッシュします。
単なるpushコマンドだと拒否されるので--force-with-leaseオプションを付与してプッシュします。
　$ git push --force-with-lease origin <ブランチ名>



## リモートの ブランチを強制的に戻す (取り消す)★★★
　$ git push -f origin ＜戻したいコミットID＞:＜ブランチ名＞
ex. git push -f origin 4a610b8ffd19f8894eb851949417e1aa4e35be99:develop_debug



## ブランチコマンド処理

例 
（前準備）
$ mkdir <作業フォルダ名>
$ cd <作業フォルダ名>
$ git init
$ git remote add origin <リポジトリのURI>

$ git add hoge.txt            変更をインデックスに登録する
$ git commit -m "Message"     コミット（HEADへインデックスの状態を記録する）

・ブランチを作成する
　$ git checkout -b <branchname> 下記2つのコマンドと等価

　　　$ git branch <branchname>   新規ブランチ作成
　　　$ git checkout <branchname> チェックアウト(HEADをbranchnameへ移動)

---
リモートブランチ をローカルに持ってくる場合
    git fetch origin <ブランチ名>
    git branch <ブランチ名> origin/<ブランチ名>   #この行は不要？
    git checkout <ブランチ名> 
リモートブランチをローカルに持ってきてチェックアウト
    git checkout -b [ローカルブランチ名] origin/[リモートブランチ名] 
---

　$ git add hoge.txt            変更ファイル設定
　$ git commit -m "Message"     コミット（branchnameへインデックスの状態を記録する）

・ブランチをマージする
　$ git checkout master         HEADをmasterへ移動
　$ git merge <branchname>      指定したブランチをHEADの指すブランチに取り込む
                             （fast-forwardマージ）

・ブランチを削除する
　$ git branch -d <branchname>
b
  (TortoiseGit)でブランチの削除
    1. 作業フォルダの右クリックメニューで、「TortoiseGit」＞「リファレンスをブラウズ」を選択する。
    2. リファレンスをブラウズ画面で、ブランチ名を右クリックする。
    3. 表示されるメニューで、「ブランチを削除」をクリックする。

・originにブランチを反映する
　$ git push origin <branchname>
                     develop等

  # ブランチ名指定するのがめんどくさい！
  # 「HEAD」指定すると「ローカルブランチを同じ名前」のリモートブランチを作成してくれます。
  $ git push origin HEAD




・リモートブランチを確認する
　$ git branch -r

・リモートブランチを削除する
　$ git push --delete origin branch_name
　　もしくは
　$ git push origin :branch_name


## ブランチ名を変更する

・ローカルブランチ名の変更方法
　$ git branch -m ＜変更前＞ ＜変更後＞

　カレントブランチが ＜変更前＞ならば以下のように省略しても可。
　$ git branch -m ＜変更後＞

・リモートブランチ名の変更方法
　リモートブランチは「名前を書き換える」のではなく、
　「旧名のブランチを削除し、改めて改名後のブランチを Push し直す」ことになる。

　1) まずは ＜変更前ブランチ名＞のリモートブランチを削除する。
　$ git push origin :＜変更前ブランチ名＞
　2) 次に改名後の fuga ブランチをローカルからプッシュする。
　$ git push origin ＜変更後ブランチ名＞


## ブランチの名前を変更(リネーム)する手順
git checkout <変更前>
git branch -M <変更後>     ;; ローカルの名前変更(-M == -m -force)
commit
git push origin :<変更前>    ;; リモートから削除
（又は git push origin --delete <変更前>）
git push origin <変更後>     ;; リモートへ追加(プッシュ)



## 変更の一時退避(stash)コマンド処理

○作業(変更差分)を退避する
　$ git stash
    or
　  git stash push -m メッセージ

    注：git commit とは違い、メッセージは クォーテーション「 "" 」で囲うとエラーになります。

  #別の作業

・退避した作業一覧をリスト表示する
　$ git stash list

・退避した内容を diff表示する
　$ git stash show -p

　HEADとの差分を確認する
　$ git diff stash@{0}


○退避した作業を元に戻す
　$ git stash pop    # 統合後、スタッシュリストから削除する
　$ git stash apply  # 統合後、スタッシュリストから削除しない

　(退避した作業が2つ以上ある場合は)
　$ git stash apply stash@{0}  # 0にはスタッシュ番号を指定
　(addした状態そのままに戻したい時は)
　$ git stash apply stash@{0} --index

・退避した作業を消す
　$ git stash drop stash@{0}
　退避した作業をすべて消す
　$ git stash clear

・戻した変更ファイル一覧を確認する
　$ git status


## ファーストフォワードによるブランチ位置の移動
　fast-forward(早送り)マージとは
	ブランチは単純に移動するだけで
	余計なコミットを作成することなく最新コミットにポインタを移動させます。

git push -f origin ＜戻したいコミットID＞:＜ブランチ名＞

git checkout -b <移動させたいID> remotes/origin/<移動させたいID> --
git merge --ff-only <移動先ID>
git.exe push --progress "origin" <移動させたいID>:<移動させたいID>


git checkout -b master_debug remotes/origin/master_debug --
git merge --ff-only develop_debug
git push --progress "origin" master_debug:master_debug2


git merge --no-ff origin/develop_debug



## Windowsのコマンドプロンプトでgitコマンドの日本語が文字化けした時の対処法
　以下を実行
　$ git config --global core.pager "LESSCHARSET=utf-8 less"

　又は、環境変数"LANG" を以下のように設定する
　$ set LANG=ja_JP.UTF-8



## リモートのブランチを削除する
　git push --delete origin <ブランチ名>

　# 続いて更新する(削除されたリモートブランチをローカルに適用する)場合
　git fetch -p
	オプション
		-p, --prune リモートで消されたブランチがあれば消す

	(fetchに自動でpruneを実行: git config --global fetch.prune true )

## ローカルのブランチを削除する
$ git branch -d <ブランチ名>


## ブランチをmasterへマージする
$ git checkout master
$ git merge <ブランチ名>


  ----------------------------------------
## リモートの最新情報をローカルに反映する
　①fetch+merge 又 は ②pull

①fetch は、リモートリポジトリからローカルリポジトリに最新情報を取得する。
　※ この時、ワークツリー(ローカルで実装しているファイルが置いてあるところ)は更新されない。
　git fetch <リモートリポジトリの名称>
　$ git fetch origin

　ワークツリーに反映させたい場合はmergeコマンド
　下記はmasterブランチを最新にしたい場合で、originのあとにスラッシュが必要。
　git merge <リモートリポジトリ名称>/<ブランチ名称>
　$ git merge origin/master


②pull は、リモートリポジトリからローカルリポジトリに最新情報を取得した上で、
　ワークツリーにもその情報を反映する。
　つまり、fetchしてmergeするのを一括で実行してくれる。

　$ git pull <リモートリポジトリ名称> <リモートブランチ名称>
　$ git pull origin master
　$ git pull origin develop

　注：git pull origin HEAD は使っては駄目！pushできなくなる危険！
    git pull origin HEADによりPullされるのはOrigin側のデフォルトブランチの先頭になるためです。
    ローカルでの作業の変更をPushする際に「git push origin HEAD」を使いますが、このHEADとは別物です。
    pull origin <topic branch>を使う


　pullする時の注意点
　pullの挙動は、現在自分がいるローカルのブランチに指定したリポートリポジトリをmergeしようとするため、
　git pullする前には必ずローカルのブランチを適切なものに変更しておくこと。

  ----------------------------------------

## Gitのコミットメッセージを後から変更する
git commit --amend -m "修正後メッセージ" -m "2行目"...

リモートも修正する場合、続けて (要 強制PUSH)
git push -f origin [<ブランチ名>]

例：
　$ git push -f origin ddbb6484babdf485f0707f4ec7bb055b42d29720:master_GA9-W

　$ git push origin develop

　$ git push origin HEAD

　　ブランチ名の代わりにHEADを使えばより簡単にプッシュできます。
　　　　HEADとはカレントブランチ（現在作業中のブランチ）のことで、
　　　　こちらも同名のリモートブランチにプッシュします。





  ----------------------------------------
## log　変更ログ表示

$ git log

　主なオプションは以下の表の通り

	オプション	説明
	-p          	各コミットソースのdiffを表示する
	-n <数字>   	表示するログの履歴数制限
	-- <fileパス名>	特定のファイルのみ表示（ワイルドカード*　使用かぬ）
	
	--name-only 	コミット情報の後に変更されたファイルの一覧を表示する
	--name-status	変更されたファイルと 追加/修正/削除 情報を表示する


	--stat      	各コミットで変更されたファイルの統計情報を表示する
	--shortstat 	--stat コマンドのうち、変更/追加/削除 の行だけを表示する

	--word-diff 	単語単位でdiffを表示する

	--pretty	コミットを別のフォーマットで表示する。
		オプションとして oneline, short, full, fuller そして format (独自フォーマットを設定する) を指定可能
	--oneline	--pretty=oneline --abbrev-commitと同じ意味の便利なオプション
	    commitIDのハッシュを7桁に短縮、1行表示

	--abbrev-commit	ハッシュの全体 (40文字) ではなく最初の9文字のみを表示す
	--relative-date	完全な日付フォーマットではなく、相対フォーマット (“2 weeks ago” など) で日付を表示する

	--graph	ブランチやマージの歴史を、ログ出力とともにアスキーグラフで表示する

例
・GUIツールっぽく1コミット1行でcommit/merge履歴を表示する
　$ git log --graph --oneline

・最新commitのソース変化点diff表示
　$ git log -p -n 1

・削除して存在しないファイルのログを確認する
　$ git log -- <ファイルPath>


  ----------------------------------------
## diff 差分を取る

　$ git diff

・変更ファイルの一覧を表示する
　$ git diff --name-status
　$ git diff --name-only


・add前（コミット前）の修正をパッチファイル化する
　$ git diff > diff.patch

　add後（コミット前）の差分を表示する
　$ git diff HEAD~1

　作成したパッチファイルを当てる
　$ patch -p1 < diff.patch


・git pull する前にリモートとの変更点を見る
　$ git diff リモート名/ブランチ名..HEAD

・現在の作業ツリーと最新のコミットとの変更点の比較
　$ git diff --cached

・git commit した後に、コミットした変更点を表示する
　$ git diff HEAD^
　（「最新のコミット」と「最新のコミットのひとつ前」との差分ということ）

・任意のコミット間の比較
　$ git diff <変更前のコミット識別子>..<変更後のコミット識別子>
・ブランチ間の比較
　$ git diff <ブランチA>..<ブランチB>

・任意のコミットの変更点を見る
　$ git diff <コミット識別子>^..<コミット識別子>

・任意の箇所のファイル変更点を見る
　$ git diff -- <ファイルパス名>

・別ファイル同士を比較する
　$ git diff -- <ファイルパスA> <ファイルパスB>

・その他 git diff オプション
　  -w                    改行コードや空白を無視する
　  --ignore-blank-lines  空行を無視する
　  -U<行数>              変更点の前後に表示される行数を変える
　                         -U0で前後の行が消えます
　  --color-words         差分を行単位ではなく単語単位で色分けして表示する

　      設定
　      $ # 出力先が端末のときに色をつけて表示する
　      $ git config --global color.ui auto


  ----------------------------------------
## add - 変更ファイルの指定

$ git add -n <確認したいオプション等>
	このオプションでは実際にaddはされず、add対象になるファイルの一覧が表示されます。

$ git add .
	カレントディレクトリ以下の、新規作成、もしくは変更があった部分のみをaddします。
	(※つまり、rmコマンドなどで削除されたファイルはaddされません。)
$ git add -u
	変更があった部分のみをaddします。
	(※つまり、新しく作られたファイルはaddされません。)
$ git add -u .
	カレントディレクトリ以下の、変更があった部分のみをaddします。
$ git add -A
	新規作成、修正、削除といった全てのファイルをaddします。


git addの取り消し
$ git restore --staged ファイル名



  ----------------------------------------
## status 戻した変更ファイル一覧を表示する
　$ git status

・コンパクトに表示する、行先頭にbranch名を表示する
　$ git status --short --branch

	凡例	説明
	  A_	新しいファイルがgit addされている
	  M_	変更がgit addされている (staged)
	  _M	変更がgit addされていない (modified)
	  _D	rmされているけどgit addやgit rmはされていない
	  ??	gitに登録されていない（untracked）
	  UU	mergeするbranchも手元も変更がありconflictした (unmerged)
	  DU	mergeするbranchで変更されたが手元では削除されいるのでconflictした


  ----------------------------------------
## リベース手順

ワークディレクトリにcommitされていないファイルがない状態にする
$ git stash
親ブランチに切り替える
$ git checkout develop
親ブランチを最新の状態にする(にリモートリポジトリの内容origin/developを反映)
$ git pull
作業ブランチに切り替え
$ git checkout feature/hoge_hoge

親ブランチをベースにリベース
$ git rebase develop
コンフリクト確認
$ git status
(手修正)
...

stash一覧の確認
$ git stash list
最新のstashを反映
$ git stash pop

...
【Git】最低限これだけ押さえる！現場で使えるgit rebaseの流れ
https://qiita.com/C_HERO/items/06669621a1eb12d8799e

状態確認
$ git log --graph


  ----------------------------------------
## マージする

git merge
  現在のブランチに対して、他のブランチで行った変更を取り込むために使うコマンドです。
  以下の例では、ブランチbug-fixをmasterブランチにマージします。
  git checkout master
  git merge bug-fix

  # mergeを取り消す場合
  git merge --abort


  CONFLICTが出たら
	# 状態確認
	git status

	対象のファイルを開くと、コンフリクト起こした部分は以下のように表示される
	<<<<<<< HEAD
	# 作業ブランチでの変更内容
	・・・
	=======
	# develop(マージしたブランチ)での変更内容
	・・・
	>>>>>>> develop

	# 編集してコンフリクト解消したことファイルをaddする
	git add <変更したファイル>

	# 状況確認
	git status

git commit -m "コンフリクト解消" # デフォルトのマージコミットメッセージを使用する場合は、git commitのみでenter。
エディタが開くので、コミットメッセージを保存。

git push origin b_branch


  ----------------------------------------
## その他

・現在のブランチの親ブランチを調べる
　$ git show-branch | grep '*'


・手元のgitリポジトリがどのURLからcloneしたものか確認する
　$ git config -l
	or
　trunk直下にて$  cat .git/config


・originやupstreamで登録したリモートリポジトリのURLの情報を確認する場合
　$ git remote -v


・未追跡ファイルが複数存在する場合に削除する
　$ git clean -df


・変更(modified)を全部破棄して元の最後のコミット状態に戻す
　（「ローカルの変更を元に戻す」を参照）
　git checkout .


・変更を打ち消すコミットを作成
　$ git revert HEAD
・特定のファイルの変更を取り消す
　$ git checkout <ファイル名orディレクトリ名>

・「git reset」についても要参照

・commit済ファイル ソース差分表示
  git show

  更に1つ前のcommit差分表示
  git show HEAD~1

  ----------------------------------------

## 参考文献

Git コマンドリファレンス（日本語版）- git公式リファレンスの日本語版
https://tracpath.com/docs/
	https://tracpath.com/docs/git-diff/
	https://tracpath.com/docs/git-branch/


Git - git Documentation
https://git-scm.com/docs/git


github個人メモ
　https://github.com/new
　https://github.com/fukuda1/test1.git
    git config --global user.name "fukuda1"
    git config --global user.email kk.fukuda.atushi@nttd-mse.com
    git config --global http.proxy http://pxswvf:fukuda%40123@ndeproxy:8080

tutorial 
https://gist.github.com/fukuda1/b341714133e58fc05653293f669ea696
https://fukuda1:atsushi1@gist.github.com/fukuda1/b341714133e58fc05653293f669ea696


CID
https://scm.dndev.net/sn03/stash/scm/fhi20display/cid.git

Windows10パソコン上にGitサーバを立ててみた - LinuxサーバがないけどGitサーバを運用したい場合の対処法
http://imamachi-n.hatenablog.com/entry/2018/06/09/170331

【 git clone 】コマンド――Gitのリポジトリを複製する：Linux基本コマンドTips（381） - ＠IT
https://atmarkit.itmedia.co.jp/ait/articles/2003/05/news006.html
